A powerful air-gapped software Point of Sale can be shared via a QR code.

Its functions include:

- Generating invoices
- Denomination in sats and ANY fiat currency
- Boltcard support
- Adding items for a checkout experience
- An ATM feature that allows you to sell Bitcoin back to your customers for a profit!

A favorite onboarding solution for merchants who want to accumulate Bitcoin, can ben achieved by also using the Boltz extension for automatic trustless swaps out to on-chain.
